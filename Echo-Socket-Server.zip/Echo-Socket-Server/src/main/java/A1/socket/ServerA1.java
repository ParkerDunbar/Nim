package A1.socket;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ServerA1 {
	public static final String OK = "HTTP/1.0 200 OK\r\n";
	public static final String BR = "HTTP/1.1 400 Bad Request\r\nContent-type: text\r\n\r\n400 Bad Request";
	public static final String NF = "HTTP/1.1 404 Not Found\r\nContent-type: text\r\n\r\n404 Not Found";
	public static final String ISE = "HTTP/1.1 500 Internal Server Error\r\nContent-type: text\r\n\r\n500 Internal Server Error";
	public static final String Base = "C:\\Users\\Tiln\\Web\\Final";
	public static String compiledEverything = "";

	public static void main(String[] args) throws IOException {
		int portNumber = Integer.parseInt(args[0]);
		ServerSocket servSock = new ServerSocket(portNumber);
		Socket sock = null;
		InputStream in;
		int b;
		try {
			while (true) {
				boolean ISEbool = false;
				boolean BRbool = false;
				boolean NFbool = false;
				String input = "";
				sock = servSock.accept();
				in = sock.getInputStream();
				while ((b = in.read()) != -1) {
					input += (char) b;
					if (input.endsWith("\r\n\r\n")) {
						break;
					}
				}
				String requestedPage = getpostregex(input);
				System.out.println(input);
				File file = new File(Base + "/index.html");
				if (input.startsWith("GET") && requestedPage.startsWith("/calc/")) {
					compiledEverything = "";
					String[] typeNumbers = calcRegex(requestedPage);
					double a = Double.parseDouble(typeNumbers[1]);
					double d = Double.parseDouble(typeNumbers[2]);
					String temp = "";
					if (typeNumbers[0].equalsIgnoreCase("add")) {
						compiledEverything += (OK + "Content-length: " + (temp += calc.Add(a, d)).length() + "\r\nContent-type: text\r\n\r\n");
						compiledEverything += calc.Add(a, d);
					} else if (typeNumbers[0].equalsIgnoreCase("subtract")) {
						compiledEverything += (OK + "Content-length: " + (temp += calc.Divide(a, d)).length() + "\r\nContent-type: text\r\n\r\n");
						compiledEverything += calc.Subtract(a, d);
					} else if (typeNumbers[0].equalsIgnoreCase("multiply")) {
						compiledEverything += (OK + "Content-length: " + (temp += calc.Multiply(a, d)).length() + "\r\nContent-type: text\r\n\r\n");
						compiledEverything += calc.Multiply(a, d);
					} else if (typeNumbers[0].equalsIgnoreCase("divide")) {
						compiledEverything += (OK + "Content-length: " + (temp += calc.Divide(a, d)).length() + "\r\nContent-type: text\r\n\r\n");
						compiledEverything += calc.Divide(a, d);
					} else {
						compiledEverything += BR;
					}

				} else if (input.startsWith("GET")) {

					if (requestedPage == "400") {
						BRbool = true;
					} else {
						if (requestedPage.length() > 1) {
							file = new File(Base + requestedPage);
						}
						if (!file.exists()) {
							NFbool = true;
						}
					}

					String BaseHeader = "Content-length: " + file.length() + "\r\n\r\n";
					compiledEverything = "";
					if (ISEbool) {
						compiledEverything += ISE;
					} else if (BRbool) {
						compiledEverything += BR;
					} else if (NFbool) {
						compiledEverything += NF;
					} else {
						compiledEverything += OK;
						compiledEverything += BaseHeader;
						FileReader fileR = new FileReader(file);
						int c;
						while ((c = fileR.read()) != -1) {
							compiledEverything += (char) c;
						}
						fileR.close();
					}
					compiledEverything += " ";

				} else if (input.startsWith("POST")) {
					file = new File(Base + requestedPage);
					input = "";
					int toRead = in.available();
					for (int i = 0; i < toRead; i++) {
						input += (char) in.read();
					}
					FileWriter fileW = new FileWriter(file);
					fileW.write(input);
					fileW.close();
					compiledEverything = "";
					compiledEverything += "HTTP/1.0 204 OK\r\n\r\n";

				}
				sock.getOutputStream().write(compiledEverything.getBytes());
				System.out.println("Done");
			}
		} catch (IOException e) {
			String ISE = "HTTP/1.1 500 Internal Server Error\r\nContent-type: text/html\r\n\r\n500 Internal Server Error";
			sock.getOutputStream().write(ISE.getBytes());
		}
		servSock.close();
	}

	public static String getpostregex(String request) {
		String whatsRequested = "";
		String rawRegex = "(?:(?:GET)|(?:POST)) (\\/.*?) HTTP\\/1\\.[0|1]";
		Pattern p = Pattern.compile(rawRegex);
		Matcher m = p.matcher(request);
		if (m.find()) {
			whatsRequested = m.group(1);
		} else {
			return "400";
		}
		return whatsRequested;

	}

	public static String[] calcRegex(String request) {
		request += "&";
		String[] whatsRequested = new String[3];
		String rawRegex = "\\/calc\\/(.*?)\\?operand1=(.*?)&operand2=(.*?)&";
		Pattern p = Pattern.compile(rawRegex);
		Matcher m = p.matcher(request);
		if (m.find()) {
			whatsRequested[0] = m.group(1);
			whatsRequested[1] = m.group(2);
			whatsRequested[2] = m.group(3);
		}
		return whatsRequested;

	}
}
