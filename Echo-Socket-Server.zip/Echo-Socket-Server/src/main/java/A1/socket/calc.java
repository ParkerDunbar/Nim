package A1.socket;

public class calc {
	public static double Add(double a, double b){return a+b;}
	public static double Subtract(double a, double b){return a-b;}
	public static double Multiply(double a, double b){return a*b;}
	public static double Divide(double a, double b){return a/(b+0.0);}
	public static double Modulate(double a, double b){return a%b;}
}
